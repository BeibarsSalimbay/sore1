package com.soreapp.sore_beta_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
